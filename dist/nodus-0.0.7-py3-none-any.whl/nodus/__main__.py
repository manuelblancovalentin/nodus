# nodus/__main__.py
from .ui import run_ui  # Replace with the actual function you want to run

if __name__ == "__main__":
    run_ui()  # Call the main function of your UI